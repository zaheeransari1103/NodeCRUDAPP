var express = require('express');
var app = express();
var port = process.env.port || 1337;

var bodyParser = require('body-parser');
// create application/x-www-form-urlencoded parser
app.use(bodyParser.urlencoded({ extended: true }));
// create application/json parser
app.use(bodyParser.json());

app.use(function (req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', 'http://localhost:1337');
    next();
  });

  app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET,HEAD,OPTIONS,POST,PUT");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
    next();
  });

var productController = require('./Controller/ProductController')();

app.use("/api/products",productController);


var studentController = require('./Controller/StudentController')();

app.use("/api/student",studentController);


app.use(express.static('public'));
app.get('/index.htm', function (req, res) {
   res.sendFile( __dirname + "/" + "index.htm" );
})

app.use(express.static('public'));
app.get('/angular.min.js', function (req, res) {
   res.sendFile( __dirname + "/" + "angular.min.js" );
})

app.use(express.static('public'));
app.get('/App.js', function (req, res) {
   res.sendFile( __dirname + "/" + "App.js" );
})

app.use(express.static('public'));
app.get('/MainCtrl.js', function (req, res) {
   res.sendFile( __dirname + "/" + "MainCtrl.js" );
})

app.use(express.static('public'));
app.get('/bootstrap.min.css', function (req, res) {
   res.sendFile( __dirname + "/" + "bootstrap.min.css" );
})

app.use(express.static('public'));
app.get('/bootstrap.css', function (req, res) {
   res.sendFile( __dirname + "/" + "bootstrap.css" );
})

app.use(express.static('public'));
app.get('/Style.css', function (req, res) {
   res.sendFile( __dirname + "/" + "Style.css" );
})

/*app.get("/product",function(request,response)
{
    response.json({"Message":"Welcome to Node js"});
});*/


app.listen(port, function () {
    var datetime = new Date();
    var message = "Server runnning on Port: " + port + " Started at : " + datetime;
    console.log(message);
});