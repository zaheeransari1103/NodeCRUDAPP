app.controller("MainCtrl", ['$scope', '$http', '$window',  function ($scope, $http, $window) {

	alert("HELLO");

$scope.SaveVissible=true;


$scope.GetDetailes = function(){
	var data = {"Action":"Select"}
	$http({
		method: 'POST',
	   	url: 'http://127.0.0.1:1337/api/student',
		dataType: 'json',
		data: data,
	}).then(function (response) {
		$scope.StudentList=response.data.recordset;
	}, function (error) {
		alert("error" + error);
	});

}
$scope.GetDetailes();



$scope.AddDetails = null;
$scope.AddDetails = function () {

	var data = { "Name": $scope.Name, "Address": $scope.Address,"City": $scope.City,"Email": $scope.Email,"PhoneNo": $scope.PhoneNo ,"Action":"Insert"}
	$http({
		method: 'POST',
	   	url: 'http://127.0.0.1:1337/api/student/Add',
		dataType: 'json',
		data: data,
	}).then(function (response) {
		alert("Data Inserted Successfully");
		$scope.GetDetailes();
		$scope.ClearAll();
	}, function (error) {
		alert("error" + error);
	});

}

$scope.EditDetails = function (Id) {
        
	$scope.SaveVissible = false;
	$scope.UpdateVissible = true;
	$scope.Id=Id;

	var data = { "Id": $scope.Id ,"Action":"ById"}
	$http({
		method: 'POST',
	   	url: 'http://127.0.0.1:1337/api/student/ById',
		dataType: 'json',
		data: data,
	}).then(function (response) {
		alert("Edited");

		$scope.Name=response.data.recordset[0].Name
		$scope.Address=response.data.recordset[0].Address
		$scope.City=response.data.recordset[0].City
		$scope.Email=response.data.recordset[0].Email
		$scope.PhoneNo=response.data.recordset[0].PhoneNo

	}, function (error) {
		alert("error" + error);
	});
	
}



$scope.UpdateDetails = function () {

	alert("Update");

	var data = { "Id":$scope.Id,"Name": $scope.Name, "Address": $scope.Address,"City": $scope.City,"Email": $scope.Email,"PhoneNo": $scope.PhoneNo ,"Action":"Update"}
	$http({
		method: 'POST',
		   url: 'http://127.0.0.1:1337/api/student/Update',
		dataType: 'json',
		data: data,
	}).then(function (response) {
		alert("Data Updated Successfully");
		$scope.GetDetailes();
		$scope.ClearAll();
	}, function (error) {
		alert("error" + error);
	});	
	
}


$scope.DeleteDetails = function (Id) {
	debugger;
	alert("Delete");
	$scope.Id=Id;

	var data = { "Id": $scope.Id ,"Action":"Delete"}
	$http({
		method: 'POST',
	   	url: 'http://127.0.0.1:1337/api/student/Delete',
		dataType: 'json',
		data: data,
	}).then(function (response) {
		
		alert("User has deleted Successfully");
		$scope.GetDetailes();

	}, function (error) {
		alert("Error. while deleting user Try Again!");
		//alert("error" + error);
	});
}

	

	
$scope.ClearAll = null;
$scope.ClearAll = function () {

$scope.Name =''; 
$scope.Address='';
$scope.City='';
$scope.Email='';
$scope.PhoneNo='';

}



}])      