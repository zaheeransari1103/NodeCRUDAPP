var sql = require("mssql");
var connect = function()
{
    var conn = new sql.ConnectionPool({
        user: 'sa',
        password: 'greysoft',
        server: 'GSS-DEV11',
        database: 'NodeDB'
    });
 
    return conn;
};

module.exports = connect;