var express = require('express');
var router = express.Router();
var sql = require("mssql");
var conn = require("../connection/connect")();

var routes = function ()
{
   
    //POST REQUEST

    //GET STUDENT
    
    
     router.route('/').post(function (req, res) 
    {
        conn.connect().then(function () {
       
        var request = new sql.Request(conn); 
        request.input('Action', sql.VarChar(50), req.body.Action)
        request.execute('USP_Student_IUDS').then(function(recordset)
        {
            conn.close();
            //res.json(recordset.recordset);
            //console.dir(recordset);
            res.send(recordset);
          //  conn.close();
        }).catch(function(err)
           {
               conn.close();
               res.status(400).send("Error While Getting Data");
           });  
     }).catch(function(err)
         {
             conn.close();
              res.status(400).send("Error While Getting Data");
         });
    });



    //GET ByID



        
    router.route('/ById').post(function (req, res) 
    {
        conn.connect().then(function () {
       
        var request = new sql.Request(conn); 
        request.input('Id', sql.Int, req.body.Id)
        request.input('Action', sql.VarChar(50), req.body.Action)
        request.execute('USP_Student_IUDS').then(function(recordset)
        {
            conn.close();
            //res.json(recordset.recordset);
            //console.dir(recordset);
            res.send(recordset);
          //  conn.close();
        }).catch(function(err)
           {
               conn.close();
               res.status(400).send("Error While Getting Data");
           });  
     }).catch(function(err)
         {
             conn.close();
              res.status(400).send("Error While Getting Data");
         });
    });

  

    //Insert

    router.route('/Add').post(function (req, res) 
    {
        conn.connect().then(function () {
            var transaction = new sql.Transaction(conn);
            transaction.begin().then(function () {
                var request = new sql.Request(transaction);
                request.input("Name", sql.VarChar(50), req.body.Name)
                request.input("Address", sql.VarChar(50), req.body.Address)
                request.input("City", sql.VarChar(50), req.body.City)
                request.input("Email", sql.VarChar(50), req.body.Email)
                request.input("PhoneNo", sql.BigInt, req.body.PhoneNo)
                request.input("Action", sql.VarChar(50), req.body.Action)
                request.execute("USP_Student_IUDS").then(function () {
                    transaction.commit().then(function (recordSet) {
                        conn.close();
                        res.status(200).send(req.body);
                    }).catch(function (err) {
                        conn.close();
                        res.status(400).send("Error while inserting data");
                    });
                }).catch(function (err) {
                    conn.close();
                    res.status(400).send("Error while inserting data");
                });
            }).catch(function (err) {
                conn.close();
                res.status(400).send("Error while inserting data");
            });
        }).catch(function (err) {
            conn.close();
            res.status(400).send("Error while inserting data");
        });
    });

   
    //Update


    router.route('/Update').post(function (req, res) 
    {
        conn.connect().then(function () {
            var transaction = new sql.Transaction(conn);
            transaction.begin().then(function () {
                var request = new sql.Request(transaction);
                request.input("Id", sql.VarChar(50), req.body.Id)
                request.input("Name", sql.VarChar(50), req.body.Name)
                request.input("Address", sql.VarChar(50), req.body.Address)
                request.input("City", sql.VarChar(50), req.body.City)
                request.input("Email", sql.VarChar(50), req.body.Email)
                request.input("PhoneNo", sql.BigInt, req.body.PhoneNo)
                request.input("Action", sql.VarChar(50), req.body.Action)
                request.execute("USP_Student_IUDS").then(function () {
                    transaction.commit().then(function (recordSet) {
                        conn.close();
                        res.status(200).send(req.body);
                    }).catch(function (err) {
                        conn.close();
                        res.status(400).send("Error while Updating data");
                    });
                }).catch(function (err) {
                    conn.close();
                    res.status(400).send("Error while Updating data");
                });
            }).catch(function (err) {
                conn.close();
                res.status(400).send("Error while Updating data");
            });
        }).catch(function (err) {
            conn.close();
            res.status(400).send("Error while Updating data");
        });
    });



    //Delete


    router.route('/Delete').post(function (req, res) 
    {
        conn.connect().then(function () {
            var transaction = new sql.Transaction(conn);
            transaction.begin().then(function () {
                var request = new sql.Request(transaction);
                request.input("Id", sql.Int, req.body.Id)
                request.input("Action", sql.VarChar(50), req.body.Action)
                request.execute("USP_Student_IUDS").then(function () {
                    transaction.commit().then(function (recordSet) {
                        conn.close();
                        res.status(200).send(req.body);
                    }).catch(function (err) {
                        conn.close();
                        res.status(400).send("Error while Deleting data");
                    });
                }).catch(function (err) {
                    conn.close();
                    res.status(400).send("Error while Deleting data");
                });
            }).catch(function (err) {
                conn.close();
                res.status(400).send("Error while Deleting data");
            });
        }).catch(function (err) {
            conn.close();
            res.status(400).send("Error while Deleting data");
        });
    });



   
    
    
    return router;


};



module.exports = routes;

